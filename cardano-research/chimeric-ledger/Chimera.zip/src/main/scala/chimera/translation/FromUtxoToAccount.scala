package chimera.translation

import scala.language.postfixOps
import chimera.transaction._
import chimera.base._
import chimera.ledger._
import chimera.translation.Equivalence.equivalent

object FromUtxoToAccount {

  def translate(t: UtxoTransaction)(implicit source: Ledger): Seq[AccountTransaction] = {
    require(t.isValid(source))
    val addresses = t.outputs.map(_.receiver).toSet ++ t.inputs.map(_.spentOutput.get.receiver)
    val balance = addresses.map(a => a -> t.balance(a)).toMap
    val (sb, rb) = balance.partition(_._2 < 0)
    val senders = sb.keys.toList
    val receivers = rb.keys.toList

    import collection.mutable.{Map => MMap}
    // State: mutable maps holding remaining balances, forges and fees
    val mustSpend = MMap(sb.mapValues(- _).toSeq:_*)
    val mustReceive = MMap(rb.toSeq:_*)
    var remForge = t.forge
    var remFee = t.fee

    def updateState(spent: Option[(Address, Value)], received: Option[(Address, Value)], fo: Value, fe: Value): Unit = {
      for ((s,v) <- spent) mustSpend(s) -= v
      for ((r,v) <- received) mustReceive(r) -= v
      remForge -= fo
      remFee -= fe
    }

    def rec(ss: List[Address], rs: List[Address]): List[AccountTransaction] = {
      (ss, rs) match {
        case (s::st, r::rt) =>
          val expectedNumberOfRemainingTransactions = List(ss.length, rs.length).max
          val fee = remFee / expectedNumberOfRemainingTransactions
          val forge = remForge / expectedNumberOfRemainingTransactions
          val v = mustSpend(s) - fee + forge
          if (mustReceive(r) == v) {
            val trans = AccountTransaction(Some(s), Some(r), v, forge, fee)
            updateState(Some((s, mustSpend(s))), Some((r, v)), forge, fee)
            trans::rec(st, rt)
          }
          else if (mustReceive(r) > v) {
            val fo = (forge * v) / mustReceive(r)
            val fe = (fee * v) / mustReceive(r)
            val trans = AccountTransaction(Some(s), Some(r), v, fo, fe)
            updateState(Some((s, mustSpend(s))), Some((r, v)), fo, fe)
            trans::rec(st, rs)
          }
          else { // mustReceive(r) < v
            val fo = (forge * mustReceive(r)) / v
            val fe = (fee * mustReceive(r)) / v
            val trans = AccountTransaction(Some(s), Some(r), mustReceive(r), fo, fe)
            updateState(Some((s, mustReceive(r) + fe - fo)), Some((r, mustReceive(r))), fo, fe)
            trans::rec(ss, rt)
          }
        case (Nil, r::rt) =>
          val v = mustReceive(r)
          val fe = remFee / rs.length
          val fo = v + fe
          val trans = AccountTransaction(None, Some(r), v, fo, fe)
          updateState(None, Some((r, v)), fo, fe)
          trans::rec(Nil,rt)
        case (s::st, Nil) =>
          val fe = remFee / ss.length
          val fo = fe - mustSpend(s)
          val trans = AccountTransaction(Some(s), None, 0, fo, fe)
          updateState(Some(s, mustSpend(s)), None, fo, fe)
          trans::rec(st,Nil)
        case (Nil, Nil) =>
          assert(mustSpend.values.sum == 0 && mustReceive.values.sum == 0 && remForge == 0 && remFee == 0)
          Nil
      }
    }
    rec(senders,receivers)
  } ensuring { r =>
    val addresses = t.outputs.map(_.receiver).toSet ++ t.inputs.map(_.spentOutput.get.receiver)
    val (sb, _) = addresses.map(a => a -> t.balance(a)).toMap.partition(_._2 < 0)
    val dummyLedger = Add(HybridTransaction(Map(), sb.mapValues(- _), - sb.values.sum), EmptyLedger)
    equivalent(Seq(t), source, r, dummyLedger)
  }

  def bumpNonce(t: AccountTransaction)(target: Ledger) = {
    def equalExceptForNonce(t1: Transaction, t2: AccountTransaction): Boolean = {
      t1.isInstanceOf[AccountTransaction] && {
        val t = t1.asInstanceOf[AccountTransaction]
        t.sender == t2.sender && t.receiver == t2.receiver && t.value == t2.value && t.fee == t2.fee
      }
    }
    val nonces = target.transactions.filter(equalExceptForNonce(_, t)).map(_.asInstanceOf[AccountTransaction].nonce)
    if (nonces.isEmpty) t else t.copy(nonce = nonces.max + 1)
  }
}
