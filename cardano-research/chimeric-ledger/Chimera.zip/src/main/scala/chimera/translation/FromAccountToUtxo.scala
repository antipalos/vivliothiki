package chimera.translation

import chimera.transaction._
import chimera.base._
import chimera.ledger._
import chimera.translation.Equivalence._
import chimera.util.distribute

object FromAccountToUtxo {

  // One-to-one: an addresses in the source ledger corresponds to the same address in the target ledger
  def translate(t: AccountTransaction)(implicit target: Ledger): Option[UtxoTransaction] = {
    val outputsOfSender = target.unspentOutputs.filter(t.sender contains _.spentOutput.get.receiver).toList
    val inputs = outputsOfSender.scanLeft((0, List[Input]())) {(r, i) => (r._1 + i.spentOutput.get.value, i::r._2)}
      .find(_._1 >= t.totalInputValue)
    inputs match {
      case None => None // sender's utxoBalance is insufficient
      case Some((v, inps)) =>
        val change = v - t.totalInputValue
        val received = t.value
        Some(
          UtxoTransaction(inps.toSet,
            List(t.receiver.map(Output(_, received)), t.sender.map(Output(_, change))).flatten.filter(_.value > 0),
            t.forge, t.fee))
    }
  } ensuring { _ match {
    case None => true
    case Some(r) =>
      val dummyLedger = t.sender match {
        case None => EmptyLedger
        case Some(s) =>
          val spent = - t.balance(s)(EmptyLedger)
          Add(AccountTransaction(None, Some(s), spent, spent, 0, t.nonce + 1), EmptyLedger)
      }
      equivalent(Seq(r), target, Seq(t), dummyLedger)
  }}

  // One-to-many: one address in the source ledger corresponds to many addresses in the target ledger
  def translate(t: AccountTransaction, addressMapping: Map[Address, Set[Address]])(implicit target: Ledger): Option[UtxoTransaction] = {
    val outputsOfSender = target.unspentOutputs.filter(i => t.sender.exists(s => addressMapping.getOrElse(s, Set(s)).contains(i.spentOutput.get.receiver))).toList
    val inputs = outputsOfSender.scanLeft((0, List[Input]())) {(r, i) => (r._1 + i.spentOutput.get.value, i::r._2)}
      .find(_._1 >= t.totalInputValue)
    inputs match {
      case None => None // sender's utxoBalance is insufficient
      case Some((v, inps)) =>
        val change = v - t.totalInputValue
        val received = t.value

        val senders = t.sender match { case None => Set[Address](); case Some(s) => addressMapping.getOrElse(s, Set(s)) }
        val receivers = t.receiver match { case None => Set[Address](); case Some(s) => addressMapping.getOrElse(s, Set(s)) }

        val trueOuts = distribute(senders, received).map(m => Output(m._1, m._2)).toList
        val changes = distribute(senders, change).map(m => Output(m._1, m._2))

        Some(UtxoTransaction(inps.toSet, trueOuts ++ changes, t.forge, t.fee))
    }
  }

}
