package chimera.translation

import chimera.base._
import chimera.ledger.{Add, EmptyLedger, Ledger}
import chimera.transaction.{CanForge, PaysFee, Transaction}
import scala.language.postfixOps

object Equivalence {
  def equivalent(t1s: Seq[Transaction], l1: Ledger, t2s: Seq[Transaction], l2: Ledger): Boolean = {
    lazy val equalTotalForge = {
      val t1sTotalForge = t1s.flatMap(_ match { case t: CanForge => Some(t.forge); case _ => None }).sum
      val t2sTotalForge = t2s.flatMap(_ match { case t: CanForge => Some(t.forge); case _ => None }).sum
      t1sTotalForge == t2sTotalForge
    }
    lazy val equalTotalFee = {
      val t1sTotalFee = t1s.flatMap(_ match { case t: PaysFee => Some(t.fee); case _ => None }).sum
      val t2sTotalFee = t2s.flatMap(_ match { case t: PaysFee => Some(t.fee); case _ => None }).sum
      t1sTotalFee == t2sTotalFee
    }
    lazy val sameBalanceUpdates = {
      def balanceUpdates(ts: Seq[Transaction], l: Ledger) = (t1s :\ (Map[Address, Value](), l1)) { (t, bl) =>
        val (previousBalanceUpdates, currentLedger) = bl
        val newBalanceUpdates = (previousBalanceUpdates /: t.parties(currentLedger)) { (u, p) =>
          u + (p -> (u.getOrElse(p, 0) + t.balance(p)(currentLedger)))
        }
        (newBalanceUpdates, Add(t, currentLedger))
      } _1
      val t1sBalanceUpdates = balanceUpdates(t1s, l1)
      val t2sBalanceUpdates = balanceUpdates(t2s, l2)
      val parties = t1sBalanceUpdates.keys.toSet ++ t2sBalanceUpdates.keys
      parties.forall(p => t1sBalanceUpdates.getOrElse(p, 0) == t2sBalanceUpdates.getOrElse(p, 0))
    }

    equalTotalForge && equalTotalFee && sameBalanceUpdates
  }
}
