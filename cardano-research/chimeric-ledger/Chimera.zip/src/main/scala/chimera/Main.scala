package chimera


object Main extends App {

}
