package chimera

import transaction.{Transaction, GeneratesOutputs}
import ledger.Ledger
import util.RichList

package object base {
  type Value = Int
  type Index = Int
  type Nonce = Int
  type Id    = Transaction
  //type Id    = Int

  def hash(t: Transaction): Id = t
  //def hash(t: Transaction): Id = t.hashCode()

  case class Address(a: Int)

  case class Output(receiver: Address, value: Value) { require(value >= 0) }
  case class Input(transactionId: Id, index: Index) { require(index >= 0)
    def transaction(implicit l: Ledger): Option[GeneratesOutputs] = l.transactions.find(hash(_) == transactionId) match {
      case Some(t:GeneratesOutputs) => Some(t.asInstanceOf[GeneratesOutputs])
      case _ => None
    }
    def spentOutput(implicit l: Ledger): Option[Output] = transaction(l) flatMap { _.outputs.get(index) }
    def value(implicit l: Ledger): Option[Value] = spentOutput map { _.value }
  }
}
