package chimera.ledger

import chimera.transaction.Transaction
import chimera.base._

sealed abstract class Ledger {
  implicit private val implicitLedger: Ledger = this

  def transactions: List[Transaction] = this match {
    case EmptyLedger => Nil
    case Add(t, l) => t::l.transactions
  }

  def accountBalance(a: Address): Value = this match {
    case EmptyLedger => 0
    case Add(t, l) => l.accountBalance(a) + t.accountBalance(a)
  }

  def utxoBalance(a: Address): Value = this match {
    case EmptyLedger => 0
    case Add(t, l) => l.utxoBalance(a) + t.utxoBalance(a)
  }

  def balance(a: Address) = accountBalance(a) + utxoBalance(a)

  def unspentOutputs: Set[Input] = this match {
    case EmptyLedger => Set[Input]()
    case Add(t, l) => l.unspentOutputs -- t.spentOutputs ++ t.unspentOutputs
  }
}
case object EmptyLedger extends Ledger
case class  Add(t: Transaction, l: Ledger) extends Ledger { require(t.isValid(l)) }