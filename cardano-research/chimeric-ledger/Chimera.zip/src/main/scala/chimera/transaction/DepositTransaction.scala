package chimera.transaction

import chimera.ledger.Ledger
import chimera.base._

case class DepositTransaction(inputs: Set[Input], depositor: Address,
                              forge: Value, fee: Value)
  extends Transaction with SpendsOutputs with CanForge with PaysFee {
  def isValid(implicit l: Ledger) = inputsReferToUnspentOutputs

  def deposited(implicit l: Ledger) = inputs.flatMap(_.spentOutput).map(_.value).sum - fee + forge

  override def accountBalance(a: Address)(implicit l:Ledger): Value =
    if (a == depositor) deposited else 0

  override def parties(implicit l: Ledger) = Set(depositor) ++ inputs.flatMap(_.spentOutput).map(_.receiver)
}
