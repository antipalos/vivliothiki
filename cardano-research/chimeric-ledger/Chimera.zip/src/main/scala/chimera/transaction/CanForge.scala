package chimera.transaction

import chimera.base.Value

trait CanForge {
  def forge: Value
}
