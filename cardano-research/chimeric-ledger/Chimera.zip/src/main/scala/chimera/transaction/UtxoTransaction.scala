package chimera.transaction

import chimera.ledger.Ledger
import chimera.base._

case class UtxoTransaction(inputs: Set[Input], outputs: List[Output], forge: Value = 0, fee: Value = 0)
  extends Transaction with SpendsOutputs with GeneratesOutputs with CanForge with PaysFee {
  require(fee >= 0 && forge >= 0)

  def isValid(implicit l: Ledger): Boolean = {
    val valueIsPreserved = inputs.toList.flatMap(_.value).sum + forge == outputs.map(_.value).sum + fee
    inputsReferToUnspentOutputs && valueIsPreserved
  }

  override def parties(implicit l: Ledger) = outputs.map(_.receiver).toSet ++ inputs.flatMap(_.spentOutput).map(_.receiver)
}
