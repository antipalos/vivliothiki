package chimera.transaction

import chimera.base._
import chimera.ledger.Ledger

case class WithdrawalTransaction(withdrawer: Address, outputs: List[Output],
                                 forge: Value, fee: Value, nonce: Nonce)
  extends Transaction with GeneratesOutputs with CanForge with PaysFee {
  private val withdrawn = outputs.map(_.value).sum + fee - forge

  override def isValid(implicit l: Ledger) = {
    val transactionIsUnique: Boolean = !l.transactions.contains(this)
    val withdrawerHasEnoughMoney = l.accountBalance(withdrawer) >= withdrawn
    transactionIsUnique && withdrawerHasEnoughMoney
  }

  override def accountBalance(a: Address)(implicit l: Ledger) = if (a == withdrawer) - withdrawn else 0

  override def parties(implicit l: Ledger) = outputs.map(_.receiver).toSet + withdrawer
}
