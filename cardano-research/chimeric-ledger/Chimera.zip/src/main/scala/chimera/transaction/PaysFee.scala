package chimera.transaction

import chimera.base.Value

trait PaysFee {
  def fee: Value
}
