package chimera.transaction

import chimera.base._

trait GeneratesOutputs { this: Transaction =>
  def outputs: List[Output]
  override def unspentOutputs: Set[Input] = outputs.zipWithIndex.map(oi => Input(hash(this), oi._2) ).toSet
  override def outputsBalance(a: Address): Value = outputs.filter(_.receiver == a).map(_.value).sum
}