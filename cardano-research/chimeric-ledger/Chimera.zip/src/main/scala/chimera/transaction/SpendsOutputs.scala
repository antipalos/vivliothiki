package chimera.transaction

import chimera.base.{Address, Input, Value}
import chimera.ledger.Ledger

trait SpendsOutputs { this: Transaction =>
  def inputs: Set[Input]
  override def spentOutputs: Set[Input] = inputs
  override def inputsBalance(a: Address)(implicit l: Ledger): Value =
    inputs.toList.flatMap(_.spentOutput).filter(_.receiver == a).map(_.value).sum

  def inputsReferToUnspentOutputs(implicit l: Ledger) = inputs forall { i => l.unspentOutputs.contains(i) }
}