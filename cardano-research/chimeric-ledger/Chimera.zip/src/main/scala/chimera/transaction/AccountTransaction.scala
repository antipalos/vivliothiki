package chimera.transaction

import chimera.ledger.Ledger
import chimera.base._

case class AccountTransaction(sender: Option[Address], receiver: Option[Address], value: Value,
                              forge: Value = 0, fee: Value = 0, nonce: Nonce = 0)
  extends Transaction with CanForge with PaysFee {
  require(value >= 0 && fee >= 0 && forge >= 0)

  val totalInputValue = if (sender.isDefined) value + fee - forge else 0
  val totalOutputValue = if (receiver.isDefined) value else 0

  require(totalInputValue + forge == totalOutputValue + fee)

  def isValid(implicit l: Ledger): Boolean = {
    val transactionIsUnique: Boolean = !l.transactions.contains(this)
    val senderHasEnoughMoney = sender.forall(s => l.accountBalance(s) >= totalInputValue)
    transactionIsUnique && senderHasEnoughMoney
  }

  override def accountBalance(a: Address)(implicit l:Ledger): Value = {
    val received = if (receiver contains a) value else 0
    val spent = if (sender contains a) totalInputValue else 0
    received - spent
  }

  override def parties(implicit l: Ledger) = Set(sender, receiver).flatten
}