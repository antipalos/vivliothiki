package chimera.transaction

import chimera.base._
import chimera.ledger.Ledger

case class HybridTransaction(inputs: Map[Address, Value], outputs: Map[Address, Value],
                                   forge: Value = 0, fee: Value = 0, nonce: Nonce = 0) extends Transaction {
  val senders = inputs.keys.toSet
  val receivers = outputs.keys.toSet
  val totalInputValue = inputs.values.sum
  val totalOutputValue = outputs.values.sum

  require(forge >= 0 && fee >= 0 && inputs.values.forall(_ >= 0) && outputs.values.forall(_ >= 0))
  require(totalInputValue + forge == totalOutputValue + fee)

  def isValid(implicit l: Ledger): Boolean = {
    val transactionIsUnique: Boolean = !l.transactions.contains(this)
    val sendersHaveEnoughMoney = senders.forall(s => l.accountBalance(s) >= inputs(s))
    transactionIsUnique && sendersHaveEnoughMoney
  }

  override def accountBalance(a: Address)(implicit l:Ledger): Value = {
    val received = outputs.getOrElse(a, 0)
    val spent = inputs.getOrElse(a, 0)
    received - spent
  }

  override def parties(implicit l: Ledger) = inputs.keys.toSet ++ outputs.keys
}