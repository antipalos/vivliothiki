package chimera

package object util {
  implicit class RichList[+T](val l: List[T]) extends AnyVal {
    def get(index: Int): Option[T] =
      if (l.isDefinedAt(index)) Some(l(index))
      else None
  }

  def distribute[A](ss: Set[A], amount: Int): Map[A, Int] =
    (ss.toList :\ (List[(A, Int)](), amount, ss.size)) { (s, acc) =>
      val (current, amountRemaining, ssRemaining) = acc
      val a = amountRemaining/ssRemaining
      ((s -> a)::current, amountRemaining, ssRemaining - 1)
    }   ._1.toMap
}
