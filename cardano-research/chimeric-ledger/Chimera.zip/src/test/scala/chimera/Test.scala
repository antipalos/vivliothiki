package chimera

import org.scalatest._

import chimera.base._
import chimera.ledger._
import chimera.transaction._
import chimera.translation._
import chimera.translation.Equivalence.equivalent

class Test extends FlatSpec with Matchers {

  val a1 = Address(1)
  val a2 = Address(2)
  val a3 = Address(3)

  // Example 1:
  val t1u = UtxoTransaction(Set(), List(Output(a1, 1000)), 1000, 0)
  val t2u = UtxoTransaction(Set(Input(hash(t1u), 0)), List(Output(a2, 800), Output(a1, 200)))
  val t3u = UtxoTransaction(Set(Input(hash(t2u), 1)), List(Output(a3, 199)), 0, 1)
  val t4u = UtxoTransaction(Set(Input(hash(t3u), 0)), List(Output(a2, 207)), 10, 2)
  val t5u = UtxoTransaction(Set(Input(hash(t4u), 0), Input(hash(t2u), 0)), List(Output(a2, 500), Output(a3, 500)), 0, 7)
  val t6u = UtxoTransaction(Set(Input(hash(t5u), 0), Input(hash(t5u), 1)), List(Output(a3, 999)), 0, 1)
  val lu1 = Add(t1u, EmptyLedger)
  val lu2 = Add(t2u, lu1)
  val lu3 = Add(t3u, lu2)
  val lu4 = Add(t4u, lu3)
  val lu5 = Add(t5u, lu4)
  val lu6 = Add(t6u, lu5)

  // Example 2:
  val t1a = AccountTransaction(None, Some(a1), 1000, 1000, 0, 0)
  val t2a = AccountTransaction(Some(a1), Some(a2), 800, 0, 0, 0)
  val t3a = AccountTransaction(Some(a1), Some(a3), 199, 0, 1, 0)
  val t4a = AccountTransaction(Some(a3), Some(a2), 207, 10, 2, 0)
  val t5a = AccountTransaction(Some(a2), Some(a3), 500, 0, 7, 0)
  val t6a = AccountTransaction(Some(a2), Some(a3), 499, 0, 1, 0)
  val la = Add(t6a, Add(t5a, Add(t4a, Add(t3a, Add(t2a, Add(t1a, EmptyLedger))))))

  "Example 1" should "have correct balances and unspent outputs" in {
    assert(lu6.balance(a3) == 999 && lu6.balance(a2) == 0 && lu6.balance(a1) == 0)
    assert(lu6.unspentOutputs == Set(Input(hash(t6u), 0)))
  }

  "Example 2" should "have correct balances" in {
    assert(la.balance(a3) == 999 && la.balance(a2) == 0 && la.balance(a1) == 0)
  }

  "Translation from Account to Utxo" should "translate transactions from Example 2 to transactions from Example 1" in {
    assert(FromAccountToUtxo.translate(t1a)(EmptyLedger) contains t1u)
    assert(FromAccountToUtxo.translate(t2a)(lu1) contains t2u)
    assert(FromAccountToUtxo.translate(t3a)(lu2) contains t3u)
    assert(FromAccountToUtxo.translate(t4a)(lu3) contains t4u)
    // The translation constructs alternative transactions in the case of t5a and t6a.
    // Therefore, we just jsut for equivalence, instead of equality.
    val t5uAlt = FromAccountToUtxo.translate(t5a)(lu4).get
    assert(equivalent(Seq(t5uAlt), lu4, Seq(t5u), lu4))
    val t6uAlt = FromAccountToUtxo.translate(t6a)(lu5).get
    assert(equivalent(Seq(t6uAlt), lu5, Seq(t6u), lu5))
  }

  "Translation from Utxo to Account" should "translate transactions from Example 1 to transactions from Example 2" in {
    assert(FromUtxoToAccount.translate(t1u)(EmptyLedger) == Seq(t1a))
    assert(FromUtxoToAccount.translate(t2u)(lu1) == Seq(t2a))
    assert(FromUtxoToAccount.translate(t3u)(lu2) == Seq(t3a))
    assert(FromUtxoToAccount.translate(t4u)(lu3) == Seq(t4a))
    assert(FromUtxoToAccount.translate(t5u)(lu4) == Seq(t5a))
    assert(FromUtxoToAccount.translate(t6u)(lu5) == Seq(t6a))
  }
}
