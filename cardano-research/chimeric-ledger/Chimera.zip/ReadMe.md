This project contains reference implementations of the concepts defined in the paper
"Chimeric Ledgers: Translating and Unifying UTxO-based and Account-based Cryptocurrencies".

The author of the paper and of this code can be revealed by decrypting the following message:

``
-----BEGIN PGP MESSAGE-----

hQEMA31YO1FZ4zWqAQgAoXqBR9dGSk89TxoAeIsAR6B99Yw/5s6jU3yduI2ic2o4
H+jdmLk+hYoFHbAu7dze+Rai0rGUEhdpYFA58ewKI04foV/OOBeYBQw3Ys1pRZgu
GDot3rAUCXRvkoxnn239YfKDYSI3JcmglronTQrQarRTBx9oYdKnG8OAZdwZzYMN
1AO3FBvOu/gB7r/XHJQEQGCAavNHY9wWfbsa5oiI582yECRPy0HsvhRDSaU85dSP
XK+CyTbbnvbrPKwg0/t8l1Kn/HsvmBzg7r4ikgRSToQFxTtiAJkL/IOcXlvPctGn
hPRmK6poL1F6SIQtUpcCqBXwZI4H3hoAqJmnshs4SNLA4wEIkiiLxRqlS2s5Tj1q
PjCX80ID0XuT8gpI/fH+EIXxI7D45OR50Xl084pW1+Cq3t5G1gfr+Z6s1eJsVaL1
sEFwmv2LbT+pJt2U6KIvuQ4qySEokQ7V3j2OWk34MAEktAUH1KhaREpTGk72wGM0
QrjmsQ/7KEZ7jW1S4kNJvfKPspX9XPArZKNwIX0Ye7KWmxmZOxCuQah+N3Wq1BjO
joeUB45Zq0xR3U+uJTKzpThmVvncBjGX3tlnrcclD0/U8ICN0Jxff1ShNDXdqLBy
/+aNC95PicMj8Nq2xj0Aih9funULBXstJio5dRJIGrRZzuMnQxlrulZ9D8YwmvYK
miDDM/96wlBP3bptoujwxrrJ/3knwqBY5z34sbDy1nj6pTdTOTb6VBJRmI/993JP
6CiLkJB7Qw1vx0GYJt2jG7catGCWWSNljPtSs5Srieg3zR7FDLC6PDgKyKkzciBG
N33xI+ulWYPKkeOHqyqOIibk6Uxqh32dgcL2CocfdiCQullprZIyX1dTua3J6+KQ
yYgScwciGqmGOM9Y0mr7YENOkVDt
=Iew3
-----END PGP MESSAGE-----
```


To test the code, install SBT and then run:
```
$ sbt test
```